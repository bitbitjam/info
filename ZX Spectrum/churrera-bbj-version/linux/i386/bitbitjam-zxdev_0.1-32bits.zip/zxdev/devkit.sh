#!/bin/sh
# Init devkit
# Writen By D_Skywalk (09-05-08)
# 

## SDK ZX
export ZXDEV=/home/david/desarrollo/spectrum/paquete/zxdev
export PATH=$PATH:$ZXDEV/bin

## SPRITELIB INSTALL
SPLIB_INSTALL_PATH=/usr/share/z88dk
SPLIB_SOURCE_PATH=$ZXDEV/splib_install

echo " "

if [ -d "$SPLIB_INSTALL_PATH/lib/clibs" ]; then
    if [ -f "$SPLIB_INSTALL_PATH/lib/clibs/splib2.lib" ]; then
        echo "SpLib2 Installed: OK!"
    else
        echo "Installing splib on: $SPLIB_INSTALL_PATH"
        echo "I need the super-user password..."
        sudo cp -vf $SPLIB_SOURCE_PATH/lib/* $SPLIB_INSTALL_PATH/lib/clibs/
        sudo cp -vf $SPLIB_SOURCE_PATH/include/* $SPLIB_INSTALL_PATH/include/
    fi
fi

echo 
echo ZX devkit by SKY
echo ------------------------
echo Path Loading!
echo on $ZXDEV
echo 
exec $SHELL
