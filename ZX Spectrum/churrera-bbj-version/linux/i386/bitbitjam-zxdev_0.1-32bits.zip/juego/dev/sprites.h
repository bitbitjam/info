// Generado por GfxCnv de la churrera
// Copyleft 2013 The Mojon Twins/Antonio Villena

extern unsigned char sprite_1_a [];
extern unsigned char sprite_1_b [];
extern unsigned char sprite_1_c [];
extern unsigned char sprite_2_a [];
extern unsigned char sprite_2_b [];
extern unsigned char sprite_2_c [];
extern unsigned char sprite_3_a [];
extern unsigned char sprite_3_b [];
extern unsigned char sprite_3_c [];
extern unsigned char sprite_4_a [];
extern unsigned char sprite_4_b [];
extern unsigned char sprite_4_c [];
extern unsigned char sprite_5_a [];
extern unsigned char sprite_5_b [];
extern unsigned char sprite_5_c [];
extern unsigned char sprite_6_a [];
extern unsigned char sprite_6_b [];
extern unsigned char sprite_6_c [];
extern unsigned char sprite_7_a [];
extern unsigned char sprite_7_b [];
extern unsigned char sprite_7_c [];
extern unsigned char sprite_8_a [];
extern unsigned char sprite_8_b [];
extern unsigned char sprite_8_c [];
extern unsigned char sprite_9_a [];
extern unsigned char sprite_9_b [];
extern unsigned char sprite_9_c [];
extern unsigned char sprite_10_a [];
extern unsigned char sprite_10_b [];
extern unsigned char sprite_10_c [];
extern unsigned char sprite_11_a [];
extern unsigned char sprite_11_b [];
extern unsigned char sprite_11_c [];
extern unsigned char sprite_12_a [];
extern unsigned char sprite_12_b [];
extern unsigned char sprite_12_c [];
extern unsigned char sprite_13_a [];
extern unsigned char sprite_13_b [];
extern unsigned char sprite_13_c [];
extern unsigned char sprite_14_a [];
extern unsigned char sprite_14_b [];
extern unsigned char sprite_14_c [];
extern unsigned char sprite_15_a [];
extern unsigned char sprite_15_b [];
extern unsigned char sprite_15_c [];
extern unsigned char sprite_16_a [];
extern unsigned char sprite_16_b [];
extern unsigned char sprite_16_c [];

#asm
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_1_a
        defb 13, 192
        defb 30, 0
        defb 221, 0
        defb 0, 0
        defb 191, 0
        defb 111, 0
        defb 109, 0
        defb 22, 0
        defb 24, 192
        defb 30, 192
        defb 14, 192
        defb 1, 128
        defb 32, 0
        defb 66, 0
        defb 132, 1
        defb 72, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_1_b
        defb 128, 63
        defb 0, 3
        defb 244, 1
        defb 2, 0
        defb 117, 0
        defb 113, 0
        defb 241, 0
        defb 50, 1
        defb 204, 3
        defb 192, 15
        defb 16, 7
        defb 200, 3
        defb 4, 1
        defb 36, 1
        defb 24, 195
        defb 0, 231
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_1_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_2_a
        defb 0, 224
        defb 13, 192
        defb 30, 0
        defb 221, 0
        defb 0, 0
        defb 191, 0
        defb 111, 0
        defb 109, 0
        defb 22, 128
        defb 48, 0
        defb 102, 0
        defb 54, 0
        defb 0, 128
        defb 32, 128
        defb 32, 128
        defb 32, 128
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_2_b
        defb 0, 127
        defb 128, 63
        defb 0, 3
        defb 244, 1
        defb 2, 0
        defb 117, 0
        defb 113, 0
        defb 241, 0
        defb 242, 1
        defb 12, 3
        defb 192, 31
        defb 192, 31
        defb 192, 31
        defb 0, 31
        defb 64, 31
        defb 64, 31
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_2_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_3_a
        defb 13, 192
        defb 30, 0
        defb 221, 0
        defb 0, 0
        defb 191, 0
        defb 111, 0
        defb 77, 0
        defb 54, 128
        defb 112, 0
        defb 103, 0
        defb 27, 128
        defb 26, 128
        defb 64, 0
        defb 140, 3
        defb 144, 7
        defb 32, 15
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_3_b
        defb 128, 63
        defb 0, 3
        defb 244, 1
        defb 2, 0
        defb 117, 0
        defb 113, 0
        defb 241, 0
        defb 242, 1
        defb 12, 3
        defb 208, 7
        defb 208, 7
        defb 8, 3
        defb 4, 1
        defb 196, 1
        defb 56, 131
        defb 0, 199
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_3_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_4_a
        defb 13, 224
        defb 30, 0
        defb 221, 0
        defb 0, 0
        defb 191, 0
        defb 111, 0
        defb 73, 0
        defb 54, 128
        defb 118, 0
        defb 57, 128
        defb 7, 192
        defb 30, 128
        defb 64, 0
        defb 68, 0
        defb 56, 131
        defb 0, 199
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_4_b
        defb 128, 31
        defb 0, 3
        defb 244, 1
        defb 2, 0
        defb 117, 0
        defb 113, 0
        defb 241, 0
        defb 242, 1
        defb 12, 3
        defb 208, 7
        defb 208, 7
        defb 8, 3
        defb 4, 1
        defb 196, 1
        defb 56, 3
        defb 0, 199
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_4_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_5_a
        defb 1, 252
        defb 0, 192
        defb 47, 128
        defb 64, 0
        defb 174, 0
        defb 142, 0
        defb 143, 0
        defb 76, 128
        defb 51, 192
        defb 3, 240
        defb 8, 224
        defb 19, 192
        defb 32, 128
        defb 36, 128
        defb 24, 195
        defb 0, 231
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_5_b
        defb 176, 3
        defb 120, 0
        defb 187, 0
        defb 0, 0
        defb 253, 0
        defb 246, 0
        defb 182, 0
        defb 104, 0
        defb 24, 3
        defb 120, 3
        defb 112, 3
        defb 128, 1
        defb 4, 0
        defb 66, 0
        defb 33, 128
        defb 18, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_5_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_6_a
        defb 0, 254
        defb 1, 252
        defb 0, 192
        defb 47, 128
        defb 64, 0
        defb 174, 0
        defb 142, 0
        defb 143, 0
        defb 79, 128
        defb 48, 192
        defb 3, 248
        defb 3, 248
        defb 3, 248
        defb 0, 248
        defb 2, 248
        defb 2, 248
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_6_b
        defb 0, 7
        defb 176, 3
        defb 120, 0
        defb 187, 0
        defb 0, 0
        defb 253, 0
        defb 246, 0
        defb 182, 0
        defb 104, 1
        defb 12, 0
        defb 102, 0
        defb 108, 0
        defb 0, 1
        defb 4, 1
        defb 4, 1
        defb 4, 1
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_6_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_7_a
        defb 1, 252
        defb 0, 192
        defb 47, 128
        defb 64, 0
        defb 174, 0
        defb 142, 0
        defb 143, 0
        defb 79, 128
        defb 48, 192
        defb 11, 224
        defb 11, 224
        defb 16, 192
        defb 32, 128
        defb 35, 128
        defb 28, 193
        defb 0, 227
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_7_b
        defb 176, 3
        defb 120, 0
        defb 187, 0
        defb 0, 0
        defb 253, 0
        defb 246, 0
        defb 178, 0
        defb 108, 1
        defb 14, 0
        defb 230, 0
        defb 216, 1
        defb 88, 1
        defb 2, 0
        defb 49, 192
        defb 9, 224
        defb 4, 240
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_7_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_8_a
        defb 1, 248
        defb 0, 192
        defb 47, 128
        defb 64, 0
        defb 174, 0
        defb 142, 0
        defb 143, 0
        defb 79, 128
        defb 48, 192
        defb 11, 224
        defb 11, 224
        defb 16, 192
        defb 32, 128
        defb 35, 128
        defb 28, 192
        defb 0, 227
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_8_b
        defb 176, 7
        defb 120, 0
        defb 187, 0
        defb 0, 0
        defb 253, 0
        defb 246, 0
        defb 146, 0
        defb 108, 1
        defb 110, 0
        defb 156, 1
        defb 224, 3
        defb 120, 1
        defb 2, 0
        defb 34, 0
        defb 28, 193
        defb 0, 227
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_8_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_9_a
        defb 0, 255
        defb 0, 255
        defb 3, 252
        defb 4, 248
        defb 10, 240
        defb 16, 224
        defb 19, 224
        defb 21, 224
        defb 23, 224
        defb 16, 224
        defb 35, 192
        defb 88, 128
        defb 168, 16
        defb 73, 176
        defb 16, 224
        defb 31, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_9_b
        defb 0, 255
        defb 0, 255
        defb 224, 31
        defb 16, 15
        defb 136, 7
        defb 4, 3
        defb 132, 3
        defb 68, 3
        defb 194, 1
        defb 1, 0
        defb 129, 0
        defb 1, 0
        defb 5, 0
        defb 197, 0
        defb 133, 0
        defb 250, 5
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_9_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_10_a
        defb 0, 255
        defb 0, 255
        defb 7, 248
        defb 8, 240
        defb 17, 224
        defb 32, 192
        defb 33, 192
        defb 34, 192
        defb 67, 128
        defb 128, 0
        defb 129, 0
        defb 128, 0
        defb 160, 0
        defb 163, 0
        defb 161, 0
        defb 95, 160
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_10_b
        defb 0, 255
        defb 0, 255
        defb 192, 63
        defb 32, 31
        defb 80, 15
        defb 8, 7
        defb 200, 7
        defb 168, 7
        defb 232, 7
        defb 8, 7
        defb 196, 3
        defb 26, 1
        defb 21, 8
        defb 146, 13
        defb 8, 7
        defb 248, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_10_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_11_a
        defb 0, 224
        defb 7, 192
        defb 13, 192
        defb 13, 192
        defb 13, 192
        defb 15, 192
        defb 7, 192
        defb 5, 192
        defb 0, 128
        defb 26, 128
        defb 25, 128
        defb 0, 128
        defb 1, 224
        defb 1, 240
        defb 0, 224
        defb 7, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_11_b
        defb 0, 15
        defb 192, 7
        defb 96, 7
        defb 96, 7
        defb 96, 7
        defb 224, 7
        defb 192, 7
        defb 64, 3
        defb 16, 3
        defb 128, 3
        defb 64, 7
        defb 0, 15
        defb 64, 15
        defb 0, 15
        defb 0, 63
        defb 0, 63
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_11_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_12_a
        defb 0, 224
        defb 7, 192
        defb 13, 192
        defb 13, 192
        defb 13, 192
        defb 15, 192
        defb 7, 192
        defb 5, 128
        defb 16, 128
        defb 5, 128
        defb 2, 192
        defb 0, 224
        defb 5, 224
        defb 1, 224
        defb 0, 248
        defb 1, 248
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_12_b
        defb 0, 15
        defb 192, 7
        defb 96, 7
        defb 96, 7
        defb 96, 7
        defb 224, 7
        defb 192, 7
        defb 64, 7
        defb 0, 3
        defb 48, 3
        defb 176, 3
        defb 0, 3
        defb 0, 15
        defb 0, 31
        defb 0, 15
        defb 192, 15
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_12_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_13_a
        defb 0, 224
        defb 11, 224
        defb 7, 224
        defb 11, 224
        defb 7, 192
        defb 20, 128
        defb 51, 128
        defb 51, 128
        defb 56, 128
        defb 23, 128
        defb 7, 192
        defb 15, 224
        defb 15, 224
        defb 14, 224
        defb 0, 224
        defb 12, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_13_b
        defb 0, 31
        defb 64, 3
        defb 136, 1
        defb 84, 1
        defb 132, 1
        defb 176, 0
        defb 54, 0
        defb 38, 0
        defb 96, 0
        defb 164, 1
        defb 132, 1
        defb 196, 17
        defb 196, 17
        defb 4, 17
        defb 196, 17
        defb 4, 17
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_13_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_14_a
        defb 0, 224
        defb 11, 224
        defb 7, 224
        defb 11, 224
        defb 7, 192
        defb 20, 128
        defb 51, 128
        defb 51, 128
        defb 56, 128
        defb 23, 128
        defb 7, 192
        defb 15, 224
        defb 15, 224
        defb 1, 224
        defb 12, 224
        defb 0, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_14_b
        defb 0, 3
        defb 72, 1
        defb 148, 1
        defb 68, 1
        defb 128, 0
        defb 182, 0
        defb 54, 0
        defb 32, 0
        defb 100, 1
        defb 164, 1
        defb 132, 1
        defb 196, 17
        defb 196, 17
        defb 196, 17
        defb 4, 17
        defb 192, 17
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_14_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_15_a
        defb 1, 0
        defb 50, 0
        defb 75, 0
        defb 120, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_15_b
        defb 128, 0
        defb 76, 0
        defb 210, 0
        defb 30, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_15_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_16_a
        defb 48, 0
        defb 73, 0
        defb 122, 0
        defb 3, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_16_b
        defb 12, 0
        defb 146, 0
        defb 94, 0
        defb 192, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

    ._sprite_16_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255

#endasm
